#' Bag of 20 marbles from Lab 5
#'
#' The population used in Lab 5 Task 3: 12 white marbles and 8 black marbles.
#'
#' @format A data frame with 20 rows and 3 variables:
#' \describe{
#'   \item{id}{marble number, 1 to 20}
#'   \item{color}{"white" or "black"}
#'   \item{white}{1 if the marble is white, 0 if black}
#' }
#' @source Lab 5, MATH 4753, University of Oklahoma.
"marbles"

#' Simulated counts from Lab 5
#'
#' 10,000 iterations of the Lab 5 simulations done from first principles with
#' \code{sample()}: a binomial experiment (n = 10 trials, p = 0.7) and draws of
#' 5 marbles without replacement from \code{\link{marbles}}.
#'
#' @format A data frame with 10000 rows and 2 variables:
#' \describe{
#'   \item{binom}{number of successes in 10 trials with p = 0.7}
#'   \item{hyper}{number of white marbles in a sample of 5 without replacement}
#' }
#' @source Simulated with \code{set.seed(4753)}, see data-raw/lab5data.R.
"lab5sims"

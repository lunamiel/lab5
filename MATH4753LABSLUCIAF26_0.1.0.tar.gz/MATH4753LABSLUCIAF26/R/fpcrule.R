#' Exact rule for when the binomial approximates the hypergeometric
#'
#' @description
#' In Lab 5 we sampled marbles with and without replacement. Without
#' replacement Y is hypergeometric, with replacement it is binomial. The
#' textbook rule says the binomial is fine when \eqn{n/N \le 0.05}. This
#' function replaces that rule of thumb with an exact answer for your
#' population: for every sample size n it computes the total variation (TV)
#' distance between Hypergeometric(N, r, n) and Binomial(n, r/N), and finds the
#' largest n where the TV distance stays at or below \code{eps}. It also
#' compares the pmfs and variances (finite population correction) at a chosen n.
#'
#' @param pop vector describing the population, one entry per item.
#' @param success the value in \code{pop} that counts as a success.
#' @param eps largest TV distance you are willing to accept.
#' @param n sample size to compare in detail. Defaults to the largest safe n.
#' @param plot logical, if \code{TRUE} draws the two panel plot.
#'
#' @return An object of class \code{"fpcrule"}, a list with
#' \describe{
#'   \item{N, r, p}{population size, number of successes, and r/N}
#'   \item{curve}{data frame of n, n/N, TV distance, and the finite population
#'   correction (N - n)/(N - 1)}
#'   \item{n_safe}{largest n with TV distance at most \code{eps}}
#'   \item{rule5_n}{largest n allowed by the textbook 5\% rule}
#'   \item{compare}{data frame comparing the two pmfs at \code{n}}
#'   \item{variance}{hypergeometric and binomial variance at \code{n}}
#' }
#' It has \code{print} and \code{plot} methods.
#'
#' @importFrom stats dhyper dbinom
#' @export
#'
#' @examples
#' # the bag of 20 marbles from Task 3 (12 white, 8 black)
#' data(marbles)
#' fr <- fpcrule(marbles$color, success = "white", eps = 0.05, n = 5)
#' fr$compare
fpcrule <- function(pop, success = 1, eps = 0.01, n = NULL, plot = TRUE) {
  N <- length(pop)
  r <- sum(pop == success)
  if (r == 0 || r == N) stop("the population needs both successes and failures")
  p <- r / N

  # TV distance between Hyp(N, r, m) and Bin(m, p) for every m
  tv_at <- function(m) {
    y <- 0:m
    0.5 * sum(abs(dhyper(y, r, N - r, m) - dbinom(y, m, p)))
  }
  ns <- seq_len(N)
  tv <- vapply(ns, tv_at, numeric(1))
  curve <- data.frame(n = ns, fraction = round(ns / N, 4), tv = round(tv, 5),
                      fpc = round((N - ns) / (N - 1), 4))

  bad <- which(tv > eps)
  n_safe <- if (length(bad) == 0) N else bad[1] - 1
  rule5_n <- floor(0.05 * N)

  if (is.null(n)) n <- max(1, n_safe)
  y <- 0:n
  hyp <- dhyper(y, r, N - r, n)
  bin <- dbinom(y, n, p)
  compare <- data.frame(y = y, hyper = round(hyp, 4), binom = round(bin, 4),
                        difference = round(hyp - bin, 4))
  variance <- c(hyper = n * p * (1 - p) * (N - n) / (N - 1),
                binom = n * p * (1 - p))

  out <- list(N = N, r = r, p = p, eps = eps, n = n, curve = curve,
              n_safe = n_safe, rule5_n = rule5_n, compare = compare,
              tv_n = tv_at(n), variance = variance)
  class(out) <- "fpcrule"
  if (plot) plot(out)
  out
}

#' @describeIn fpcrule Print a summary.
#' @param x a \code{"fpcrule"} object.
#' @param ... not used.
#' @export
print.fpcrule <- function(x, ...) {
  cat("Population: N =", x$N, " successes r =", x$r,
      " p =", round(x$p, 4), "\n")
  cat("Largest n with TV distance <=", x$eps, ":", x$n_safe,
      " (n/N =", round(x$n_safe / x$N, 3), ")\n")
  cat("Largest n allowed by the 5% rule:", x$rule5_n, "\n\n")
  cat("Comparison at n =", x$n, " (TV distance =", round(x$tv_n, 4), ")\n")
  print(x$compare, row.names = FALSE)
  cat("\nVariance  hypergeometric:", round(x$variance[["hyper"]], 4),
      "  binomial:", round(x$variance[["binom"]], 4),
      "  ratio (FPC):", round(x$variance[["hyper"]] / x$variance[["binom"]], 4),
      "\n")
  invisible(x)
}

#' @describeIn fpcrule Plot the TV curve and the pmf comparison.
#' @importFrom graphics barplot legend par abline plot.default
#' @export
plot.fpcrule <- function(x, ...) {
  old <- par(mfrow = c(1, 2), mar = c(4.5, 4.5, 3, 1))
  on.exit(par(old))

  cv <- x$curve
  plot.default(cv$fraction, cv$tv, type = "b", pch = 19,
               col = ifelse(cv$tv <= x$eps, "#6B8E4E", "#E07A5F"),
               xlab = "Sampling fraction n/N", ylab = "TV distance",
               main = "How wrong is the binomial?")
  abline(h = x$eps, lty = 2, col = "#7A3E1D")
  abline(v = 0.05, lty = 3, col = "#4F6F3A")
  abline(v = x$n_safe / x$N, lty = 1, col = "#6B8E4E")
  legend("topleft", bty = "n", cex = 0.8,
         legend = c("eps", "5% rule", "exact safe n/N"),
         lty = c(2, 3, 1), col = c("#7A3E1D", "#4F6F3A", "#6B8E4E"))

  m <- rbind(x$compare$hyper, x$compare$binom)
  barplot(m, beside = TRUE, names.arg = x$compare$y,
          col = c("#A3C585", "#D9C8A0"), border = "#4F6F3A",
          xlab = "Number of successes (Y)", ylab = "Probability",
          main = paste0("Hypergeometric vs binomial (n = ", x$n, ")"))
  legend("topleft", bty = "n", cex = 0.8, fill = c("#A3C585", "#D9C8A0"),
         legend = c("without replacement", "with replacement"))
  invisible(x)
}

#' Check a discrete simulation against its exact distribution
#'
#' @description
#' Takes the counts from a simulation (like the ones made by \code{mybin()} or
#' \code{myhyper()} in Lab 5) and compares them to the exact pmf. Instead of just
#' eyeballing a barplot, it puts simultaneous 95\% Wilson confidence bands
#' (Bonferroni adjusted) on every bar, checks whether each exact probability is
#' inside its band, computes the total variation (TV) distance between the
#' simulated and exact distributions, and compares it to the theoretical
#' expected TV distance, which shrinks like \eqn{1/\sqrt{iter}}. It also tells
#' you how many iterations you would need so every bar is within a chosen
#' margin of error at the same time.
#'
#' @param y numeric vector of simulated values (one value per iteration).
#' @param pmf function that returns the exact probability of each value,
#'   for example \code{function(k) dbinom(k, 10, 0.7)}.
#' @param support vector of possible values. Defaults to \code{min(y):max(y)}.
#' @param conf overall (simultaneous) confidence level for the bands.
#' @param margin target margin of error used to plan the number of iterations.
#' @param plot logical, if \code{TRUE} draws the two panel plot.
#'
#' @return An object of class \code{"simband"}, a list with
#' \describe{
#'   \item{table}{data frame with value, count, simulated proportion, exact
#'   probability, lower and upper band, and whether the exact value is covered}
#'   \item{iter}{number of iterations}
#'   \item{tv}{observed total variation distance}
#'   \item{expected_tv}{theoretical expected TV distance for this many iterations}
#'   \item{trace}{data frame of TV distance after each chunk of iterations}
#'   \item{iter_needed}{iterations needed for every bar to be within \code{margin}}
#'   \item{coverage}{proportion of values whose exact probability is inside its band}
#' }
#' It has \code{print} and \code{plot} methods.
#'
#' @importFrom stats qnorm
#' @export
#'
#' @examples
#' # binomial simulation from Task 2 (n = 10, p = 0.7)
#' data(lab5sims)
#' sb <- simband(lab5sims$binom, pmf = function(k) dbinom(k, 10, 0.7),
#'               support = 0:10)
#' sb$table
simband <- function(y, pmf, support = NULL, conf = 0.95, margin = 0.01,
                    plot = TRUE) {
  if (!is.numeric(y) || length(y) < 2) {
    stop("'y' must be a numeric vector with at least 2 simulated values")
  }
  if (!is.function(pmf)) stop("'pmf' must be a function")
  if (is.null(support)) support <- seq(min(y), max(y))

  iter <- length(y)
  k <- length(support)
  count <- as.numeric(table(factor(y, levels = support)))
  phat <- count / iter
  exact <- pmf(support)

  # Bonferroni so all k bands hold at the same time
  z <- qnorm(1 - (1 - conf) / (2 * k))

  # Wilson score interval (works better than the usual one near 0 and 1)
  centre <- (phat + z^2 / (2 * iter)) / (1 + z^2 / iter)
  half <- z * sqrt(phat * (1 - phat) / iter + z^2 / (4 * iter^2)) /
    (1 + z^2 / iter)
  lower <- pmax(0, centre - half)
  upper <- pmin(1, centre + half)
  covered <- exact >= lower & exact <= upper

  # total variation distance, including exact mass outside the support
  tv_fun <- function(p) 0.5 * sum(abs(p - exact)) + 0.5 * max(0, 1 - sum(exact))
  tv <- tv_fun(phat)

  # E|phat - p| is about sqrt(2 p (1 - p) / (pi * iter)) for large iter
  exp_tv <- function(m) 0.5 * sum(sqrt(2 * exact * (1 - exact) / (pi * m)))

  # TV distance after the first m iterations, for a grid of m values
  grid <- unique(round(exp(seq(log(min(10, iter)), log(iter), length.out = 40))))
  trace_tv <- vapply(grid, function(m) {
    tv_fun(as.numeric(table(factor(y[1:m], levels = support))) / m)
  }, numeric(1))
  trace <- data.frame(iter = grid, tv = trace_tv,
                      expected_tv = vapply(grid, exp_tv, numeric(1)))

  # iterations so every bar is within 'margin' simultaneously
  iter_needed <- ceiling(z^2 * max(exact * (1 - exact)) / margin^2)

  out <- list(
    table = data.frame(value = support, count = count,
                       simulated = round(phat, 4), exact = round(exact, 4),
                       lower = round(lower, 4), upper = round(upper, 4),
                       covered = covered),
    iter = iter, conf = conf, margin = margin, tv = tv,
    expected_tv = exp_tv(iter), trace = trace,
    iter_needed = iter_needed, coverage = mean(covered)
  )
  class(out) <- "simband"
  if (plot) plot(out)
  out
}

#' @describeIn simband Print a summary of the comparison.
#' @param x a \code{"simband"} object.
#' @param ... not used.
#' @export
print.simband <- function(x, ...) {
  cat("Simulation check with", x$conf * 100, "% simultaneous Wilson bands\n")
  cat("Iterations:", x$iter, "\n\n")
  print(x$table, row.names = FALSE)
  cat("\nExact probabilities inside their band:",
      sum(x$table$covered), "of", nrow(x$table), "\n")
  cat("TV distance (observed):", round(x$tv, 4),
      "  expected for this many iterations:", round(x$expected_tv, 4), "\n")
  cat("Iterations needed for every bar within +/-", x$margin, ":",
      x$iter_needed, "\n")
  invisible(x)
}

#' @describeIn simband Plot the bands and the convergence trace.
#' @importFrom graphics barplot arrows points legend par lines abline plot.default
#' @export
plot.simband <- function(x, ...) {
  tab <- x$table
  old <- par(mfrow = c(1, 2), mar = c(4.5, 4.5, 3, 1))
  on.exit(par(old))

  mids <- barplot(tab$simulated, names.arg = tab$value,
                  col = ifelse(tab$covered, "#A3C585", "#E07A5F"),
                  border = "#4F6F3A", ylim = c(0, max(tab$upper) * 1.15),
                  xlab = "Value (Y)", ylab = "Proportion",
                  main = paste0("Simulated vs exact (iter = ", x$iter, ")"))
  arrows(mids, tab$lower, mids, tab$upper, angle = 90, code = 3,
         length = 0.04, col = "#2F4F2F")
  points(mids, tab$exact, pch = 19, col = "#7A3E1D")
  legend("topleft", bty = "n", cex = 0.8,
         legend = c("simulated", "exact", "band misses exact"),
         pch = c(15, 19, 15), col = c("#A3C585", "#7A3E1D", "#E07A5F"))

  tr <- x$trace
  plot.default(tr$iter, tr$tv, log = "xy", type = "b", pch = 19,
               col = "#6B8E4E", xlab = "Iterations (log)",
               ylab = "TV distance (log)",
               ylim = range(c(tr$tv[tr$tv > 0], tr$expected_tv)),
               main = "Convergence to the exact pmf")
  lines(tr$iter, tr$expected_tv, lty = 2, lwd = 2, col = "#7A3E1D")
  legend("topright", bty = "n", cex = 0.8,
         legend = c("observed", "expected (1/sqrt(iter))"),
         lty = c(1, 2), col = c("#6B8E4E", "#7A3E1D"))
  invisible(x)
}

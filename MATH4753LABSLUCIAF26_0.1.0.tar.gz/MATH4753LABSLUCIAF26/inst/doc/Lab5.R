## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 9, fig.height = 4)

## ----setup--------------------------------------------------------------------
library(MATH4753LABSLUCIAF26)

## -----------------------------------------------------------------------------
head(marbles)
head(lab5sims)

## -----------------------------------------------------------------------------
# binomial simulation from Task 2
sb <- simband(lab5sims$binom, pmf = function(k) dbinom(k, 10, 0.7),
              support = 0:10)
sb

## -----------------------------------------------------------------------------
# marble simulation from Task 3
sh <- simband(lab5sims$hyper, pmf = function(k) dhyper(k, 12, 8, 5),
              support = 0:5, margin = 0.005)
sh

## -----------------------------------------------------------------------------
fr <- fpcrule(marbles$color, success = "white", eps = 0.05, n = 5)
fr

